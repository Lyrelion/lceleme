export default {
    title:"lcelm",
    baseUrl:{
        dev:"/api/", // 开发时 后台接口地址
      pro:"/api/" //上线产品 后台接口地址
    },
    imgBaseUrl: ''
}