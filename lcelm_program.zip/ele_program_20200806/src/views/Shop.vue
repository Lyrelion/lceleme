<template>
  <div>
    店铺内部
  </div>
</template>

<script>
export default {
  name:'Shop'
}
</script>